export type SplitterSize = number | `${number}%` | 'auto';
export interface SplitterPanelConstraint {
    min?: number | `${number}%`;
    max?: number | `${number}%`;
    collapsible?: boolean;
}
export interface ResolveSplitterSizesOptions {
    containerSize: number;
    sizes: SplitterSize[];
    panels: SplitterPanelConstraint[];
}
export interface ResizeAdjacentPanelsOptions {
    sizes: number[];
    panels: SplitterPanelConstraint[];
    containerSize?: number;
    handleIndex: number;
    delta: number;
}
export type SplitterLayout = 'horizontal' | 'vertical';
export interface SplitterProps {
    sizes?: SplitterSize[];
    defaultSizes?: SplitterSize[];
    layout?: SplitterLayout;
    lazy?: boolean;
    disabled?: boolean;
}
