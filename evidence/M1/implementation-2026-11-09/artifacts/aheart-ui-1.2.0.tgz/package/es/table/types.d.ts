import type { ExtractPropTypes, PropType, VNodeChild } from 'vue';
import type { AheartSize } from '../config';
import type { PaginationQuickJumperConfig } from '../pagination/types';
export type TableKey = string | number;
export type TableRecord = Record<string, unknown>;
export type TableSize = AheartSize;
export type TableSortOrder = 'ascend' | 'descend';
export type TableSelectionType = 'checkbox' | 'radio';
export type TableColumnAlign = 'left' | 'center' | 'right';
export type TableDataMode = 'local' | 'server';
export type TableDataIndex = string | number | Array<string | number>;
export type TableFilterValue = string | number | boolean;
export type TableChangeAction = 'paginate' | 'sort' | 'filter';
export type TableRenderable = VNodeChild;
export type TableColumnFixed = 'left' | 'right';
export type TableScroll = {
    x?: true | number | string;
    y?: number | string;
};
export type TableSticky = boolean | {
    offsetHeader?: number;
};
export interface TableVirtualConfig {
    height?: number;
    estimateSize?: number;
    overscan?: number;
}
export type TableVirtual = boolean | TableVirtualConfig;
export type TableFilterDropdownContext = {
    selectedKeys: TableFilterValue[];
    setSelectedKeys: (keys: TableFilterValue[]) => void;
    confirm: () => void;
    clearFilters: () => void;
    close: () => void;
};
export interface TableColumnFilter {
    text: TableRenderable;
    value: TableFilterValue;
}
export interface TableColumn<T extends TableRecord = TableRecord> {
    title: TableRenderable;
    dataIndex?: keyof T | TableDataIndex;
    key?: string;
    align?: TableColumnAlign;
    width?: string | number;
    className?: string;
    hidden?: boolean;
    sorter?: boolean | ((a: T, b: T) => number);
    sortOrder?: TableSortOrder | null;
    defaultSortOrder?: TableSortOrder;
    filters?: TableColumnFilter[];
    filteredValue?: TableFilterValue[];
    defaultFilteredValue?: TableFilterValue[];
    filterMultiple?: boolean;
    filterDropdown?: (context: TableFilterDropdownContext) => VNodeChild;
    filterDropdownOpen?: boolean;
    defaultFilterDropdownOpen?: boolean;
    fixed?: TableColumnFixed;
    ellipsis?: boolean;
    customRender?: (context: {
        text: unknown;
        record: T;
        index: number;
        column: TableColumn<T>;
    }) => VNodeChild;
}
export interface TablePaginationConfig {
    current?: number;
    defaultCurrent?: number;
    pageSize?: number;
    defaultPageSize?: number;
    total?: number;
    simple?: boolean;
    hideOnSinglePage?: boolean;
    showTotal?: boolean;
    showSizeChanger?: boolean;
    totalBoundaryShowSizeChanger?: number;
    pageSizeOptions?: Array<number | string>;
    showQuickJumper?: boolean | PaginationQuickJumperConfig;
}
export interface TableSorter<T extends TableRecord = TableRecord> {
    column?: TableColumn<T>;
    columnKey?: string;
    field?: TableDataIndex;
    order?: TableSortOrder;
}
export interface TableChangePagination {
    current: number;
    pageSize: number;
    total: number;
}
export type TableFilters = Record<string, TableFilterValue[]>;
export interface TableChangeExtra<T extends TableRecord = TableRecord> {
    currentDataSource: T[];
    action: TableChangeAction;
}
export interface TableRowSelection<T extends TableRecord = TableRecord> {
    selectedRowKeys?: TableKey[];
    defaultSelectedRowKeys?: TableKey[];
    type?: TableSelectionType;
    disabled?: boolean;
    getCheckboxProps?: (record: T) => {
        disabled?: boolean;
    };
    preserveSelectedRowKeys?: boolean;
}
export interface TableExpandable<T extends TableRecord = TableRecord> {
    expandedRowKeys?: TableKey[];
    defaultExpandedRowKeys?: TableKey[];
    expandedRowRender?: (record: T, index: number) => VNodeChild;
    rowExpandable?: (record: T) => boolean;
}
export declare const tableProps: {
    readonly columns: PropType<any[]>;
    readonly dataSource: PropType<TableRecord[]>;
    readonly dataMode: PropType<TableDataMode>;
    readonly rowKey: {
        readonly type: PropType<string | ((record: TableRecord) => TableKey)>;
        readonly default: "key";
    };
    readonly bordered: BooleanConstructor;
    readonly loading: BooleanConstructor;
    readonly size: PropType<AheartSize>;
    readonly disabled: {
        readonly type: BooleanConstructor;
        readonly default: undefined;
    };
    readonly pagination: {
        readonly type: PropType<false | TablePaginationConfig>;
        readonly default: undefined;
    };
    readonly rowSelection: PropType<any>;
    readonly expandable: PropType<any>;
    readonly scroll: PropType<TableScroll>;
    readonly sticky: PropType<TableSticky>;
    readonly virtual: {
        readonly type: PropType<TableVirtual>;
        readonly default: false;
    };
    readonly error: PropType<boolean | {
        message?: TableRenderable;
        retryText?: TableRenderable;
    }>;
    readonly getPopupContainer: PropType<(triggerNode: HTMLElement) => HTMLElement | false>;
    readonly showHeader: {
        readonly type: BooleanConstructor;
        readonly default: true;
    };
    readonly emptyText: {
        readonly type: PropType<VNodeChild>;
        readonly default: undefined;
    };
};
export declare const tableEmits: {
    change: (_pagination: TableChangePagination, _filters: TableFilters, _sorter: TableSorter, _extra: TableChangeExtra) => boolean;
    'update:selectedRowKeys': (keys: TableKey[]) => boolean;
    'update:expandedRowKeys': (keys: TableKey[]) => boolean;
    select: (_key: TableKey, _selected: boolean, _record: TableRecord, _selectedRowKeys: TableKey[]) => boolean;
    selectAll: (_selected: boolean, keys: TableKey[], rows: TableRecord[]) => boolean;
    expand: (_expanded: boolean, _record: TableRecord, _key: TableKey) => boolean;
    filterDropdownOpenChange: (_columnKey: string, _open: boolean) => boolean;
    retry: () => boolean;
};
export type TableProps = ExtractPropTypes<typeof tableProps>;
